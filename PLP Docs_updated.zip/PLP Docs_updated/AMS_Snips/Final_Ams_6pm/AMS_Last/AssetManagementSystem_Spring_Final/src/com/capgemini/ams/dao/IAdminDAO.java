package com.capgemini.ams.dao;


import java.time.LocalDate;

import com.capgemini.ams.bean.Asset;
import com.capgemini.ams.exception.AssetException;

public interface IAdminDAO {

	boolean addAsset(Asset asset)throws AssetException;

	boolean allocateAsset(long requestId, LocalDate releaseDate)throws AssetException;
	
	boolean generateReport() throws AssetException;

	boolean modifyAsset(Asset asset)throws AssetException;

}

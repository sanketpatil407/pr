package com.capgemini.ams.service;

import com.capgemini.ams.bean.UserMaster;
import com.capgemini.ams.exception.AssetException;

public interface IAuthenticationService 
{
	String getUserType(String userName, String password) throws AssetException;

	boolean validateUser(UserMaster user) throws AssetException;
}

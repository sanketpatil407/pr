package com.capgemini.ams.dao;

import com.capgemini.ams.bean.AssetRequest;
import com.capgemini.ams.exception.AssetException;

public interface IManagerDAO {

	public long raiseRequest(AssetRequest assetRequest) throws AssetException;

}
